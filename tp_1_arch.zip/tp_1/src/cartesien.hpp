#ifndef gardien_point_cart
#define gardien_point_cart
#include "point.hpp"
#include "polaire.hpp"

class Polaire;		/* Afin de garantir l'exisence de Cartesien */

class Cartesien : public Point 
{
	private:
		double x;
		double y;
		
	public:
		Cartesien();
		Cartesien(double abs, double ord);
		
		double getX() const;
		void setX(double abs);
		double getY() const;
		void setY(double ord);
		
		void afficher(std::stringstream &s) const;
		void convertir(Polaire& p);
		void convertir(Cartesien& c);
		
		
};
	
#endif		

