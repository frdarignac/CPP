#include "point.hpp"

using namespace std;

ostream& operator<<(ostream& os, const Point& p)
{
	stringstream ss;
	p.afficher(ss);
	os << ss.str();
	return os;
}
