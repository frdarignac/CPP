#include "polaire.hpp"

Polaire::Polaire(){
	
ang = 0.0;
dist = 0.0;
	
}

Polaire::Polaire(double angle = 0.0, double distance = 0.0) : ang(angle),dist(distance)
{
	
}

double Polaire::getAngle() const
{
	return ang;
}

void Polaire::setAngle(double angle)
{	
	ang = angle;
}

double Polaire::getDistance() const
{
	return dist;
}

void Polaire::setDistance(double distance)
{
	dist = distance;
}
void Polaire::afficher(std::stringstream &s) const
{
	s << "(a=" << ang << ";d=" << dist << ")";
}

void Polaire::convertir(Polaire& p)
{
	
}

void Polaire::convertir(Cartesien& c)
{
	
}
