#ifndef gardien_point
#define gardien_point

#include <iostream>
#include <sstream>

class Polaire;
class Cartesien;

class Point
{
	public:
		virtual void afficher(std::stringstream &s) const = 0;
		virtual void convertir(Polaire& p) = 0;
		virtual void convertir(Cartesien& c) = 0;
};
		
#endif

std::ostream& operator<<(std::ostream& os, const Point& p);
