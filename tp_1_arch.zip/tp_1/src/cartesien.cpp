#include "cartesien.hpp"

Cartesien::Cartesien()
{
	x = 0.0;
	y = 0.0;	
}

Cartesien::Cartesien(double abs = 0.0, double ord = 0.0) : x(abs),y(ord)
{
	
}

double Cartesien::getX() const
{
	return x;
}

void Cartesien::setX(double abs)
{	
	x = abs;
}

double Cartesien::getY() const
{
	return y;
}

void Cartesien::setY(double ord)
{
	y = ord;
}
void Cartesien::afficher(std::stringstream &s) const
{
	s << "(x=" << x << ";y=" << y << ")";
}

void Cartesien::convertir(Polaire& p)
{
	p.setAngle(this.x);
	p.setDistance(this.y);
}

void Cartesien::convertir(Cartesien& c)
{
	
}



