#ifndef gardien_point_pol
#define gardien_point_pol
#include "point.hpp"
#include "cartesien.hpp" 

class Cartesien;	/* Afin de garantir l'exisence de Cartesien */

class Polaire : public Point 
{
	private:
		double ang;
		double dist;
		
	public:
		Polaire();
		Polaire(double angle, double distance);
		
		double getAngle() const;
		void setAngle(double angle);
		double getDistance() const;
		void setDistance(double distance);
		
		void afficher(std::stringstream &s) const;
		void convertir(Polaire& p);
		void convertir(Cartesien& c);
		
};
	
#endif
